
# LexPass

AI-powered legal awareness platform.

## Setup

1. Install backend deps
2. Setup Supabase
3. Run FastAPI
