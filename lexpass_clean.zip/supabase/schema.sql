
create table laws (
    id uuid primary key,
    title text,
    full_text text,
    simple_explanation text,
    source_url text,
    country_code text
);
