
from utils.law_fetcher import get_relevant_laws
from utils.ai import call_ai

STRICT_PROMPT = """
You are LexPass — a legal AI assistant.

ONLY use provided laws.

FORMAT:
✔ YOUR RIGHTS:
📜 LAW:
🧠 MEANING:
🎯 ACTIONS:
⚠ DON'TS:
🔗 SOURCE:
📊 CONFIDENCE:
"""

def generate_legal_response(query: str, country: str):

    laws = get_relevant_laws(query, country)

    if not laws:
        return {"error": "No verified law found"}

    context = "\n\n".join([
        f"{law['title']}: {law['full_text']}"
        for law in laws
    ])

    prompt = f"Query: {query}\nCountry: {country}\n\n{context}"

    response = call_ai(prompt)

    return {"response": response}
