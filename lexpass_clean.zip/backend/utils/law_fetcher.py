
from utils.db import supabase

def get_relevant_laws(query, country):
    res = supabase.table("laws").select("*").eq("country_code", country).limit(5).execute()
    return res.data if res.data else []
