
from fastapi import FastAPI
from agent.legal_agent import generate_legal_response

app = FastAPI()

@app.get("/")
def home():
    return {"message": "LexPass API running"}

@app.get("/agent")
def agent(query: str, country: str):
    return generate_legal_response(query, country)
